## Network Access

!INCLUDE "guides/network_access/quote.md"

### Summary

!INCLUDE "guides/network_access/summary.md"

### Purpose 

!INCLUDE "guides/network_access/purpose.md"

### Approach

!INCLUDE "guides/network_access/approach.md"

### Output

!INCLUDE "guides/network_access/output.md"

### Operational Security

!INCLUDE "guides/network_access/operational_security.md"

### Resources

!INCLUDE "references/network_access.md"
