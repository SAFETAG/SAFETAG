## Roadmap Development

!INCLUDE "guides/roadmap_development/quote.md"

### Summary

!INCLUDE "guides/roadmap_development/summary.md"

### Purpose

!INCLUDE "guides/roadmap_development/purpose.md"

### Approach

!INCLUDE "guides/roadmap_development/approach.md"

### Output

!INCLUDE "guides/roadmap_development/output.md"

### Operational Security

!INCLUDE "guides/roadmap_development/operational_security.md"

### Resources [stub]

!INCLUDE "references/roadmap_development.overview.md"

!INCLUDE "references/determine_urgency.md"
