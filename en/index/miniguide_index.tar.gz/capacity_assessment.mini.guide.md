## Capacity Assessment

!INCLUDE "guides/capacity_assessment/quote.md"

### Summary

!INCLUDE "guides/capacity_assessment/summary.md"

### Purpose

!INCLUDE "guides/capacity_assessment/purpose.md"

### Approach

!INCLUDE "guides/capacity_assessment/approach.md"

### Output

!INCLUDE "guides/capacity_assessment/output.md"

### Resources

!INCLUDE "references/capacity_assessment.overview.md"
