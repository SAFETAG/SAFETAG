## Physical Assessment

!INCLUDE "guides/physical_assessment/quote.md"

### Summary

!INCLUDE "guides/physical_assessment/summary.md"

### Purpose

!INCLUDE "guides/physical_assessment/purpose.md"

### Approach

!INCLUDE "guides/physical_assessment/approach.md"

### Output

!INCLUDE "guides/physical_assessment/output.md"

### Operational Security

!INCLUDE "guides/physical_assessment/operational_security.md"

### Resources [stub]

!INCLUDE "references/physical_assessment.overview.md"

!INCLUDE "references/physical_assessment.md"
