## Follow Up 

!INCLUDE "guides/follow_up/quote.md"

### Summary

!INCLUDE "guides/follow_up/summary.md"

### Purpose

!INCLUDE "guides/follow_up/purpose.md"

### Approach

!INCLUDE "guides/follow_up/approach.md"

### Operational Security

!INCLUDE "guides/follow_up/operational_security.md"

### Resources

!INCLUDE "references/follow_up.md"
