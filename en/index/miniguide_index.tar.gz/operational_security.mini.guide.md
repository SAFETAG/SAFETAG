## Operational Security

!INCLUDE "guides/operational_security/quote.md"

### Summary

!INCLUDE "guides/operational_security/summary.md"

### Purpose

!INCLUDE "guides/operational_security/purpose.md"

### General Guidelines

!INCLUDE "guides/operational_security/guidelines.md"

### Resources

!INCLUDE "references/operational_security.overview.md"
