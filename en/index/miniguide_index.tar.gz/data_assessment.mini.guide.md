## Data Assessment

!INCLUDE "guides/data_assessment/quote.md"

### Summary

!INCLUDE "guides/data_assessment/summary.md"

### Purpose

!INCLUDE "guides/data_assessment/purpose.md"

### Approach

!INCLUDE "guides/data_assessment/approach.md"

### Output

!INCLUDE "guides/data_assessment/output.md"

### Operational Security

!INCLUDE "guides/data_assessment/operational_security.md"

### Resources

!INCLUDE "references/data_assessment.overview.md"
