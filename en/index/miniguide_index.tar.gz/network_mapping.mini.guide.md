## Network Mapping

!INCLUDE "guides/network_mapping/quote.md"

### Summary

!INCLUDE "guides/network_mapping/summary.md"

### Purpose

!INCLUDE "guides/network_mapping/purpose.md"

### Approach

!INCLUDE "guides/network_mapping/approach.md"

### Output

!INCLUDE "guides/network_mapping/output.md"

### Operational Security

!INCLUDE "guides/network_mapping/operational_security.md"

### Resources

!INCLUDE "references/network_mapping.overview.md"

!INCLUDE "references/network_mapping_methods.md"
